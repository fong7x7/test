package com.workfront.usernotebuilder;

import org.junit.runner.*;
import org.springframework.boot.test.*;
import org.springframework.test.context.junit4.*;

/**
 */
@RunWith(SpringJUnit4ClassRunner.class)
@SpringApplicationConfiguration(classes = ServiceApplication.class)
public class AbstractSpringTest extends AbstractUnitTest {
}
