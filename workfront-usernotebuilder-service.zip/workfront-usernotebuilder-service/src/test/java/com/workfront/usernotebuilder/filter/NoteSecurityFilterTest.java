package com.workfront.usernotebuilder.filter;

public class NoteSecurityFilterTest extends AbstractFilterTest {

	@Override
	public void predicate() {

		//CNC implement
	}

	@Override
	public void chain() throws Exception {

		//CNC implement
	}
}