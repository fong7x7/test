package com.workfront.usernotebuilder.filter;

public class PrivateUpdateUserFilterTest extends AbstractFilterTest {

	@Override
	public void predicate() {

		//CNC implement
	}

	@Override
	public void chain() throws Exception {

		//CNC implement
	}
}