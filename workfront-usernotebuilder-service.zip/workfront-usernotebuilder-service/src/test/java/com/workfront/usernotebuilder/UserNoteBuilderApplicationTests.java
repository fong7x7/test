package com.workfront.usernotebuilder;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.SpringApplicationConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

@RunWith(SpringJUnit4ClassRunner.class)
@SpringApplicationConfiguration(classes = ServiceApplication.class)
public class UserNoteBuilderApplicationTests {

	//Test comment for pull request based review
	@Test
	public void contextLoads() {
	}
}
